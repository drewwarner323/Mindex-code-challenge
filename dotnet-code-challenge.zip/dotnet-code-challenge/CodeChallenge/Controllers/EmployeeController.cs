﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CodeChallenge.Services;
using CodeChallenge.Models;

namespace CodeChallenge.Controllers
{
    [ApiController]
    [Route("api/employee")]
    public class EmployeeController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IEmployeeService _employeeService;

        public EmployeeController(ILogger<EmployeeController> logger, IEmployeeService employeeService)
        {
            _logger = logger;
            _employeeService = employeeService;
        }

        [HttpPost]
        public IActionResult CreateEmployee([FromBody] Employee employee)
        {
            _logger.LogDebug($"Received employee create request for '{employee.FirstName} {employee.LastName}'");

            _employeeService.Create(employee);

            return CreatedAtRoute("getEmployeeById", new { id = employee.EmployeeId }, employee);
        }

        [HttpGet("{id}", Name = "getEmployeeById")]
        public IActionResult GetEmployeeById(String id)
        {
            _logger.LogDebug($"Received employee get request for '{id}'");

            var employee = _employeeService.GetById(id);

            if (employee == null)
                return NotFound();

            return Ok(employee);
        }

        [HttpPut("{id}")]
        public IActionResult ReplaceEmployee(String id, [FromBody]Employee newEmployee)
        {
            _logger.LogDebug($"Recieved employee update request for '{id}'");

            var existingEmployee = _employeeService.GetById(id);
            if (existingEmployee == null)
                return NotFound();

            _employeeService.Replace(existingEmployee, newEmployee);

            return Ok(newEmployee);
        }

        [HttpGet("rptstruct/{id}", Name = "getRptStructByEmpId")]
        //Get Reporting structure by the employee id
        public IActionResult getRptStructByEmpId(String id)
        {
            _logger.LogDebug($"Received reporting structure get request for '{id}'");

            var rptStruct = _employeeService.GetByEmpId(id);

            if (rptStruct == null)
                return NotFound();

            return Ok(rptStruct);
        }
        
        [HttpGet("compensation/{id}", Name = "getCompByEmpId")]
        //Get compensation data by the employee id
        public IActionResult getCompByEmpId(String id)
        {
            _logger.LogDebug($"Received compensation data get request for '{id}'");

            var existingEmployee = _employeeService.GetCompByEmpId(id);

            if (existingEmployee == null)
                return NotFound();

            return Ok(existingEmployee);
        }

        [HttpPut("compensation/{id}", Name = "ReplaceComp")]
        public IActionResult UpdateEmployeeComp(String id, [FromBody] Compensation comp)
        {
            _logger.LogDebug($"Recieved compensation insert request for '{comp.employee.FirstName} {comp.employee.LastName}'");

            var existingEmployee = _employeeService.GetById(id);
            if (existingEmployee == null)
                return NotFound();

            // set compensation equal to value to return Id
            comp = _employeeService.UpdateComp(existingEmployee, comp);

            return Ok(comp);
        }
    }
}
