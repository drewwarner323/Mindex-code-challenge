﻿namespace CodeChallenge.Models
{
    public class ReportingStructure
    {
        public Employee employee { get; set; }
        public int numberOfReports { get; set; }
    }
}
