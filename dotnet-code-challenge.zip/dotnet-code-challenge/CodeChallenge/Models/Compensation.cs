﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CodeChallenge.Models
{
    public class Compensation
    {
        public String Id { get; set; }
        public Employee employee { get; set; }
        public double? Salary { get; set; }
        public DateTime? EffectiveDate { get; set; }
    }
}
