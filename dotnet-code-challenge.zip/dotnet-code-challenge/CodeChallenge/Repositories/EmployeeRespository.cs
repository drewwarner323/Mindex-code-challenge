﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeChallenge.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using CodeChallenge.Data;

namespace CodeChallenge.Repositories
{
    public class EmployeeRespository : IEmployeeRepository
    {
        private readonly EmployeeContext _employeeContext;
        private readonly ILogger<IEmployeeRepository> _logger;

        public EmployeeRespository(ILogger<IEmployeeRepository> logger, EmployeeContext employeeContext)
        {
            _employeeContext = employeeContext;
            _logger = logger;
        }

        public Employee Add(Employee employee)
        {
            employee.EmployeeId = Guid.NewGuid().ToString();
            _employeeContext.Employees.Add(employee);
            return employee;
        }

        public Employee GetById(string id)
        {
            Employee retval = new Employee();
            //DirectReports returning as null from original solution - return full list for employeeid
            retval = _employeeContext.Employees.Where(e => e.EmployeeId == id).Include(e => e.DirectReports).ThenInclude(e => e.DirectReports).SingleOrDefault();
            return retval;
        }    

        public Task SaveAsync()
        {
            return _employeeContext.SaveChangesAsync();
        }

        public Employee Remove(Employee employee)
        {
            return _employeeContext.Remove(employee).Entity;
        }

        public ReportingStructure GetByEmpId(string id)
        {
            ReportingStructure retval = new ReportingStructure();
            retval.employee = GetById(id);
            retval.numberOfReports = 0;
            //Calculate NumberOfReports for nested DirectReports
            if (retval.employee.DirectReports != null)
            {
                if (retval.employee.DirectReports.Count > 0)
                {
                    //Loop through DirectReports using a counter
                    foreach (var employee in retval.employee.DirectReports)
                    {
                        retval.numberOfReports++;
                        foreach (var emp in employee.DirectReports)
                        {
                            retval.numberOfReports++;
                        }
                    } ;
                }
            }             
            return retval;
        }

        public Compensation GetCompByEmpId(string id)
        {
            Compensation retval = new Compensation();
            // Grab Compensation based on unique EmployeeId
            retval = _employeeContext.Compensations.Where(e => e.employee.EmployeeId == id).SingleOrDefault();
            retval.employee = GetById(id);

            return retval;
        }

        public Compensation UpdateComp(Employee originalEmployee, Compensation comp)
        {
            Compensation retval = _employeeContext.Compensations.Where(e => e.employee.EmployeeId == originalEmployee.EmployeeId).SingleOrDefault();
            if (retval != null)
            {
                //Assign salary values to Compensation
                retval.Salary = comp.Salary;
                retval.EffectiveDate = comp.EffectiveDate;
                //update this entry in compensation dbset
                _employeeContext.Compensations.Update(retval);
            }

            return retval;
        }
    }
}
