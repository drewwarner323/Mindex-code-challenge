﻿using CodeChallenge.Models;
using System;
using System.Threading.Tasks;

namespace CodeChallenge.Repositories
{
    public interface IEmployeeRepository
    {
        Employee GetById(String id);
        Employee Add(Employee employee);
        Employee Remove(Employee employee);
        //Add for getting ReportingStructure by employee id
        ReportingStructure GetByEmpId(String id);
        //Add for inserting comp data
        Compensation UpdateComp(Employee originalEmployee, Compensation comp);
        //Add for getting compensation data by employee id
        Compensation GetCompByEmpId(String id);
        Task SaveAsync();
    }
}