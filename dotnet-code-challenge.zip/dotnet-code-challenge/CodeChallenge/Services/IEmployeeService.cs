﻿using CodeChallenge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeChallenge.Services
{
    public interface IEmployeeService
    {
        Employee GetById(String id);
        Employee Create(Employee employee);
        Employee Replace(Employee originalEmployee, Employee newEmployee);
        //Add for getting ReportingStructure by employee id
        ReportingStructure GetByEmpId(String id);
        //Add for inserting comp data
        Compensation UpdateComp(Employee originalEmployee, Compensation comp);
        //Add for getting compensation data by employee id
        Compensation GetCompByEmpId(String id);
    }
}
